<?php
/**
 * Core Taxonomy Functions for ExtraChill Search Plugin
 *
 * Placeholder for future multisite taxonomy archive functionality.
 * Taxonomy badge display handled by ExtraChill theme.
 *
 * @package ExtraChill\Search
 * @since 1.0.0
 */

// Taxonomy archive sharing functionality deferred for future implementation